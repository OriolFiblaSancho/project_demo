This is a little game that Im making in HTML, CSS and JS its the first game that I do in JS and its just a demo, pls give feedback to: oriolfibla@iesmontsia.org
